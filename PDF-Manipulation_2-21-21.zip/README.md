# PDF-Merging
Listing files creates a document with all the possible PDF names.
It then takes input from the user on the source and then destination.
The merger merges all the files in different folders into a single PDF file.
